Put .mp3 files in this folder, then use /play with the file name (for example: /play song.mp3).
/play also accepts a direct link to an audio file (a link that ends in .mp3, .ogg, etc).
