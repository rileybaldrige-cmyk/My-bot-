const { SlashCommandBuilder, AttachmentBuilder, MessageFlags } = require('discord.js');

// needs ANTHROPIC_API_KEY in .env
// optional: AI_ALLOWED_USERS=123,456 (discord user ids) so only those people can use it

const history = new Map();   // "mode:userId" -> last few messages
const lastUsed = new Map();  // userId -> time of last request

const prompts = {
  ask: 'You are a helpful assistant inside a Discord server. Keep answers short and clear.',
  code: 'You are a coding assistant. Write working code in fenced code blocks with the language name. Keep the explanation short and mention anything the user has to install or change.',
};

async function callClaude(mode, userId, text) {
  const key = mode + ':' + userId;
  const messages = [...(history.get(key) || []), { role: 'user', content: text }];

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
      max_tokens: mode === 'code' ? 4096 : 1000,
      system: prompts[mode],
      messages,
    }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error((data.error && data.error.message) || res.statusText);

  const answer = data.content.filter(b => b.type === 'text').map(b => b.text).join('\n');
  messages.push({ role: 'assistant', content: answer });
  history.set(key, messages.slice(-10)); // remember the last 5 exchanges
  return answer;
}

// returns an error message to show, or null if the user is allowed to go ahead
function blocked(i) {
  if (!process.env.ANTHROPIC_API_KEY) return 'The AI is not set up yet (no API key in .env).';

  const allowed = (process.env.AI_ALLOWED_USERS || '').split(',').map(x => x.trim()).filter(Boolean);
  if (allowed.length > 0 && !allowed.includes(i.user.id)) return "You're not allowed to use the AI commands.";

  const wait = 10000 - (Date.now() - (lastUsed.get(i.user.id) || 0));
  if (wait > 0) return `Slow down, try again in ${Math.ceil(wait / 1000)}s.`;

  lastUsed.set(i.user.id, Date.now());
  return null;
}

async function run(i, mode, text) {
  const problem = blocked(i);
  if (problem) return i.reply({ content: problem, flags: MessageFlags.Ephemeral });

  await i.deferReply();
  try {
    const answer = await callClaude(mode, i.user.id, text);
    if (answer.length <= 1900) return i.editReply(answer || '(empty answer)');

    // too long for a discord message, send it as a file
    const file = new AttachmentBuilder(Buffer.from(answer, 'utf8'), { name: 'answer.md' });
    await i.editReply({ content: 'That was long, so it is in the file.', files: [file] });
  } catch (err) {
    console.log('AI request failed:', err.message);
    await i.editReply("Couldn't get an answer. Check the API key and that your account has credit.");
  }
}

module.exports = [
  {
    data: new SlashCommandBuilder().setName('ask').setDescription('Ask Claude anything')
      .addStringOption(o => o.setName('prompt').setDescription('Your question').setRequired(true)),
    async execute(i) {
      await run(i, 'ask', i.options.getString('prompt'));
    },
  },

  {
    data: new SlashCommandBuilder().setName('code').setDescription('Ask Claude to write or fix code')
      .addStringOption(o => o.setName('request').setDescription('What should the code do? You can paste code too').setRequired(true)),
    async execute(i) {
      await run(i, 'code', i.options.getString('request'));
    },
  },

  {
    data: new SlashCommandBuilder().setName('clear').setDescription('Make Claude forget our chat'),
    async execute(i) {
      history.delete('ask:' + i.user.id);
      history.delete('code:' + i.user.id);
      await i.reply({ content: 'Done, starting fresh.', flags: MessageFlags.Ephemeral });
    },
  },
];
