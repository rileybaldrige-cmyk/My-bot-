const fs = require('fs');
const path = require('path');
const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const {
  joinVoiceChannel, createAudioPlayer, createAudioResource, entersState,
  VoiceConnectionStatus, AudioPlayerStatus,
} = require('@discordjs/voice');

// ffmpeg comes from the ffmpeg-static package
try {
  process.env.FFMPEG_PATH = require('ffmpeg-static');
} catch (e) {
  console.log('ffmpeg-static is missing, run npm install');
}

const musicDir = path.join(__dirname, '..', 'music');
const queues = new Map(); // guildId -> { player, connection, songs }

function getQueue(guildId) {
  if (queues.has(guildId)) return queues.get(guildId);

  const q = { player: createAudioPlayer(), connection: null, songs: [] };
  // when a song ends, drop it and start the next one
  q.player.on(AudioPlayerStatus.Idle, () => {
    q.songs.shift();
    playNext(q);
  });
  q.player.on('error', err => console.log('player error:', err.message));

  queues.set(guildId, q);
  return q;
}

function playNext(q) {
  const song = q.songs[0];
  if (song) q.player.play(createAudioResource(song.source));
}

// a link to an audio file, or a file name inside /music
function findSong(input) {
  if (input.startsWith('http://') || input.startsWith('https://')) {
    return { source: input, title: input };
  }
  const name = path.basename(input);
  const full = path.join(musicDir, name);
  if (fs.existsSync(full)) return { source: full, title: name };
  return null;
}

const ephemeral = MessageFlags.Ephemeral;

module.exports = [
  {
    data: new SlashCommandBuilder().setName('play').setDescription('Play a song in your voice channel')
      .addStringOption(o => o.setName('song').setDescription('Audio link or file name from the music folder').setRequired(true)),
    async execute(i) {
      const channel = i.member.voice.channel;
      if (!channel) return i.reply({ content: 'Join a voice channel first.', flags: ephemeral });

      const song = findSong(i.options.getString('song'));
      if (!song) {
        return i.reply({ content: "Couldn't find that. Use a direct audio link or a file in the music folder (see /songs).", flags: ephemeral });
      }

      await i.deferReply();
      const q = getQueue(i.guild.id);

      if (!q.connection) {
        q.connection = joinVoiceChannel({
          channelId: channel.id,
          guildId: i.guild.id,
          adapterCreator: i.guild.voiceAdapterCreator,
        });
        q.connection.on(VoiceConnectionStatus.Destroyed, () => queues.delete(i.guild.id));
        try {
          await entersState(q.connection, VoiceConnectionStatus.Ready, 20000);
        } catch (err) {
          q.connection.destroy();
          return i.editReply("Couldn't join the voice channel.");
        }
        q.connection.subscribe(q.player);
      }

      q.songs.push(song);
      if (q.songs.length === 1) {
        playNext(q);
        await i.editReply('Now playing: ' + song.title);
      } else {
        await i.editReply('Added to the queue: ' + song.title);
      }
    },
  },

  {
    data: new SlashCommandBuilder().setName('skip').setDescription('Skip the current song'),
    async execute(i) {
      const q = queues.get(i.guild.id);
      if (!q || q.songs.length === 0) return i.reply({ content: 'Nothing is playing.', flags: ephemeral });
      q.player.stop();
      await i.reply('Skipped.');
    },
  },

  {
    data: new SlashCommandBuilder().setName('stop').setDescription('Stop and clear the queue'),
    async execute(i) {
      const q = queues.get(i.guild.id);
      if (!q) return i.reply({ content: 'Nothing is playing.', flags: ephemeral });
      q.songs = [];
      q.player.stop();
      await i.reply('Stopped.');
    },
  },

  {
    data: new SlashCommandBuilder().setName('leave').setDescription('Leave the voice channel'),
    async execute(i) {
      const q = queues.get(i.guild.id);
      if (!q || !q.connection) return i.reply({ content: "I'm not in a voice channel.", flags: ephemeral });
      q.connection.destroy();
      await i.reply('Bye!');
    },
  },

  {
    data: new SlashCommandBuilder().setName('queue').setDescription('Show the song queue'),
    async execute(i) {
      const q = queues.get(i.guild.id);
      if (!q || q.songs.length === 0) return i.reply({ content: 'The queue is empty.', flags: ephemeral });
      const lines = q.songs.slice(0, 10).map((s, n) => `${n === 0 ? 'Now' : n}. ${s.title}`);
      await i.reply(lines.join('\n'));
    },
  },

  {
    data: new SlashCommandBuilder().setName('songs').setDescription('List the files in the music folder'),
    async execute(i) {
      let files = [];
      try {
        files = fs.readdirSync(musicDir).filter(f => /\.(mp3|ogg|wav|flac|m4a)$/i.test(f));
      } catch (e) {
        // no music folder
      }
      if (files.length === 0) return i.reply({ content: 'The music folder has no songs yet.', flags: ephemeral });
      await i.reply(files.slice(0, 25).join('\n'));
    },
  },
];
