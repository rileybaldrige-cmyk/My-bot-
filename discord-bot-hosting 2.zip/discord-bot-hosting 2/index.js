require('dotenv').config();
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { Client, GatewayIntentBits, REST, Routes, Events, Collection, MessageFlags } = require('discord.js');
const db = require('./db');
const tickets = require('./tickets');

const { DISCORD_TOKEN, CLIENT_ID, GUILD_ID } = process.env;
const useMembers = process.env.MEMBERS_INTENT === 'true';

const intents = [
  GatewayIntentBits.Guilds,
  GatewayIntentBits.GuildVoiceStates,
  GatewayIntentBits.GuildMessages,
];
if (useMembers) intents.push(GatewayIntentBits.GuildMembers);

const client = new Client({ intents });

// every file in /commands exports a list of commands
const commands = new Collection();
const files = fs.readdirSync(path.join(__dirname, 'commands')).filter(f => f.endsWith('.js'));
for (const file of files) {
  for (const cmd of require('./commands/' + file)) {
    commands.set(cmd.data.name, cmd);
  }
}

client.once(Events.ClientReady, async () => {
  console.log('Logged in as ' + client.user.tag);

  const rest = new REST().setToken(DISCORD_TOKEN);
  const body = commands.map(c => c.data.toJSON());
  const route = GUILD_ID
    ? Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID)
    : Routes.applicationCommands(CLIENT_ID);

  // only talk to discord about commands when something changed
  const hashFile = path.join(__dirname, '.commands-hash');
  const hash = crypto.createHash('md5').update(JSON.stringify([CLIENT_ID, GUILD_ID, body])).digest('hex');
  let oldHash = '';
  try {
    oldHash = fs.readFileSync(hashFile, 'utf8');
  } catch (e) {
    // first run
  }
  // also ask discord what it has, in case the commands got wiped (bot kicked and re-added, etc)
  const live = await rest.get(route).catch(() => []);
  if (hash !== oldHash || live.length !== body.length) {
    await rest.put(route, { body });
    fs.writeFileSync(hashFile, hash);
    console.log(`Registered ${body.length} slash commands.`);
  } else {
    console.log(`${body.length} slash commands already registered.`);
  }

  if (!useMembers) {
    console.log('Members intent is off: welcome messages, auto role and join/leave logs are disabled.');
  }
});

client.on(Events.InteractionCreate, async i => {
  try {
    if (i.isChatInputCommand()) {
      // no guild means the bot was never properly added to this server
      if (!i.guild) {
        return i.reply({
          content: "I'm not fully added to this server. Open the invite link again, pick this server and press Authorize.",
          flags: MessageFlags.Ephemeral,
        });
      }
      const cmd = commands.get(i.commandName);
      if (cmd) await cmd.execute(i);
    } else if (i.isButton() && i.customId.startsWith('ticket_')) {
      await tickets.handleButton(i);
    }
  } catch (err) {
    console.error(err);
    const msg = { content: 'Something broke: ' + String(err.message).slice(0, 300), flags: MessageFlags.Ephemeral };
    if (i.deferred || i.replied) i.followUp(msg).catch(() => {});
    else i.reply(msg).catch(() => {});
  }
});

// these three only fire if MEMBERS_INTENT=true
client.on(Events.GuildMemberAdd, async member => {
  const settings = db.get(member.guild.id);

  if (settings.welcome) {
    const channel = await member.guild.channels.fetch(settings.welcome).catch(() => null);
    if (channel) channel.send(`Welcome to ${member.guild.name}, ${member}!`).catch(() => {});
  }
  if (settings.autorole) {
    member.roles.add(settings.autorole).catch(err => console.log('auto role failed:', err.message));
  }
  db.log(member.guild, `${member.user.tag} joined.`);
});

client.on(Events.GuildMemberRemove, member => {
  db.log(member.guild, `${member.user.tag} left.`);
});

client.on(Events.MessageDelete, msg => {
  if (!msg.guild || (msg.author && msg.author.bot)) return;
  const who = msg.author ? msg.author.tag : 'someone';
  db.log(msg.guild, `A message from ${who} was deleted in <#${msg.channelId}>.`);
});

client.login(DISCORD_TOKEN);
